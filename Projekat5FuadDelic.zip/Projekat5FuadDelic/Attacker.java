package projekat5;

public interface Attacker {
	
    int getEffectiveDamage();
}
