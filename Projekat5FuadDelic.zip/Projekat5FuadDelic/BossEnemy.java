package projekat5;

public class BossEnemy extends Enemy {

    public BossEnemy(String type, int damage, int health,
                     int x, int y, Collidable collider) {

        super(type, damage, health, x, y, collider);
    }

    @Override
    public int getEffectiveDamage() {
        return super.getEffectiveDamage() * 2;
    }

    @Override
    public String toString() {
        return "BossEnemy{type='" + getType() + "', damage=" + getDamage() + 
               " (effective: " + getEffectiveDamage() + "), health=" + getHealth() + 
               ", position=(" + getX() + ", " + getY() + ")}";
    }
}
