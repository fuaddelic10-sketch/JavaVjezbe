package projekat5;

public class CircleCollider implements Collidable {

    private int cx;
    private int cy;
    private int radius;

    public CircleCollider(int cx, int cy, int radius) {
        if (radius <= 0) {
            throw new IllegalArgumentException("Poluprečnik mora biti pozitivan");
        }

        this.cx = cx;
        this.cy = cy;
        this.radius = radius;
    }

    public int getCenterX() {
        return cx;
    }

    public int getCenterY() {
        return cy;
    }

    public int getRadius() {
        return radius;
    }
    
    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    public boolean intersects(Collidable other) {

        if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;

            long dx = this.cx - c.cx;
            long dy = this.cy - c.cy;
            long rs = this.radius + c.radius;
            int distance = (int) Math.sqrt(dx * dx + dy * dy);

            return distance <= rs;
        }

        if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;

            int closestX = clamp(cx, r.getX(), r.getX() + r.getWidth());
            int closestY = clamp(cy, r.getY(), r.getY() + r.getHeight());

            long dx = cx - closestX;
            long dy = cy - closestY;
            int distance = (int) Math.sqrt(dx * dx + dy * dy);

            return distance <= radius;
        }

        return false;
    }

    @Override
    public String toString() {
        return "Circle[cx=" + cx + ", cy=" + cy + ", r=" + radius + "]";
    }
}
