package projekat5;

public interface Collidable {
	
    boolean intersects(Collidable other);
}
