package projekat5;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GUI extends JFrame {
    private JTextField nameField, healthField, xField, yField;
    private JComboBox<String> colliderChoice;
    private JTextArea resultArea;
    private Game game;
    
    public GUI() {
        setTitle("Game Setup");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        
        game = new Game();
        
        JPanel inputPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        inputPanel.add(new JLabel("Ime igrača:"));
        nameField = new JTextField("Heroj");
        inputPanel.add(nameField);
        
        inputPanel.add(new JLabel("Health (0-100):"));
        healthField = new JTextField("100");
        inputPanel.add(healthField);
        
        inputPanel.add(new JLabel("Pozicija X:"));
        xField = new JTextField("50");
        inputPanel.add(xField);
        
        inputPanel.add(new JLabel("Pozicija Y:"));
        yField = new JTextField("50");
        inputPanel.add(yField);
        
        inputPanel.add(new JLabel("Tip kolajdera:"));
        colliderChoice = new JComboBox<>(new String[]{"Pravougaonik", "Krug"});
        inputPanel.add(colliderChoice);
        
        JButton startButton = new JButton("Pokreni igru");
        startButton.addActionListener(e -> startGame());
        inputPanel.add(new JLabel());
        inputPanel.add(startButton);
        
        add(inputPanel, BorderLayout.NORTH);
        
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(resultArea);
        add(scrollPane, BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    private void startGame() {
        try {
            String name = nameField.getText();
            int health = Integer.parseInt(healthField.getText());
            int x = Integer.parseInt(xField.getText());
            int y = Integer.parseInt(yField.getText());
            
            Collidable collider;
            if (colliderChoice.getSelectedIndex() == 0) {
                collider = new RectangleCollider(x, y, 32, 32);
            } else {
                collider = new CircleCollider(x, y, 16);
            }
            
            Player player = new Player(name, health, x, y, collider);
            game.setPlayer(player);
            
            ArrayList<Enemy> enemies = Game.loadEnemies("src/projekat5/enemies.csv");
            for (Enemy enemy : enemies) {
                game.addEnemy(enemy);
            }
            
            game.resolveCollisions();
            
            displayResults();
            
            if (player.getHealth() == 0) {
                JOptionPane.showMessageDialog(this, "PORAZ! Igrač je poražen!", 
                                            "Kraj igre", JOptionPane.ERROR_MESSAGE);
            } else if (game.collidingWithPlayer().isEmpty()) {
                JOptionPane.showMessageDialog(this, "POBJEDA! Igrač je preživio!", 
                                            "Kraj igre", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Igra završena! Health: " + player.getHealth(), 
                                            "Status", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Greška: " + ex.getMessage(), 
                                        "Greška", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void displayResults() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("=== STATUS IGRAČA ===\n");
        sb.append(game.getPlayer().toString()).append("\n\n");
        
        sb.append("=== SVI NEPRIJATELJI ===\n");
        for (Enemy e : game.getEnemies()) {
            sb.append(e.toString()).append("\n");
        }
        sb.append("\n");
        
        sb.append("=== NEPRIJATELJI U KOLIZIJI ===\n");
        ArrayList<Enemy> colliding = game.collidingWithPlayer();
        if (colliding.isEmpty()) {
            sb.append("Nema kolizija\n");
        } else {
            for (Enemy e : colliding) {
                sb.append(e.toString()).append("\n");
            }
        }
        sb.append("\n");
        
        sb.append("=== LOG DOGAĐAJA ===\n");
        for (String logEntry : game.getLog()) {
            sb.append(logEntry).append("\n");
        }
        
        resultArea.setText(sb.toString());
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GUI());
    }
}