package projekat5;

import java.util.ArrayList;
import java.io.*;

class Game {
    private Player player;
    private ArrayList<Enemy> enemies;
    private ArrayList<String> log;
    
    public Game() {
        this.enemies = new ArrayList<>();
        this.log = new ArrayList<>();
    }
    
    public Player getPlayer() {
    	return player;	
    }
    public void setPlayer(Player player) {
    	this.player = player;
    	}
    
    public ArrayList<Enemy> getEnemies() {
    	return enemies;
    	}
    public ArrayList<String> getLog() {
    	return log;
    	}
    
    public boolean checkCollision(Player p, Enemy e) {
        return p.intersects(e);
    }
    
    public void decreaseHealth(Player p, Enemy e) {
        int effectiveDamage = e.getEffectiveDamage();
        int newHealth = Math.max(0, p.getHealth() - effectiveDamage);
        p.setHealth(newHealth);
        String logEntry = "Player " + p.getName() + " pogođen od " + e.getType() + 
                         " za " + effectiveDamage + " damage. Health: " + newHealth;
        log.add(logEntry);
    }
    
    public void addEnemy(Enemy e) {
        enemies.add(e);
        log.add("Dodat neprijatelj: " + e.getType() + " na poziciji (" + 
                e.getX() + ", " + e.getY() + ")");
    }
    
    public ArrayList<Enemy> findByType(String query) {
        ArrayList<Enemy> result = new ArrayList<>();
        String lowerQuery = query.toLowerCase();
        for (Enemy e : enemies) {
            if (e.getType().toLowerCase().contains(lowerQuery)) {
                result.add(e);
            }
        }
        return result;
    }
    
    public ArrayList<Enemy> collidingWithPlayer() {
        ArrayList<Enemy> colliding = new ArrayList<>();
        if (player != null) {
            for (Enemy e : enemies) {
                if (checkCollision(player, e)) {
                    colliding.add(e);
                }
            }
        }
        return colliding;
    }
    
    public void resolveCollisions() {
        if (player == null) return;
        
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                log.add("Kolizija detektovana: " + player.getName() + " i " + e.getType());
                decreaseHealth(player, e);
            }
        }
    }
    
    public static ArrayList<Enemy> loadEnemies(String filePath) throws IOException {
        ArrayList<Enemy> loadedEnemies = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        
        // Skip header
        br.readLine();
        
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",", -1);
            if (parts.length < 10) {
                throw new IllegalArgumentException("Neispravan CSV zapis");
            }
            
            try {
                String type = parts[0].trim();
                String enemyClass = parts[1].trim().toLowerCase();
                int damage = Integer.parseInt(parts[2].trim());
                int health = Integer.parseInt(parts[3].trim());
                int x = Integer.parseInt(parts[4].trim());
                int y = Integer.parseInt(parts[5].trim());
                String shape = parts[6].trim().toLowerCase();
                
                Collidable collider;
                if (shape.equals("rectangle")) {
                    int width = Integer.parseInt(parts[7].trim());
                    int height = Integer.parseInt(parts[8].trim());
                    collider = new RectangleCollider(x, y, width, height);
                } else if (shape.equals("circle")) {
                    int radius = Integer.parseInt(parts[9].trim());
                    collider = new CircleCollider(x, y, radius);
                } else {
                    throw new IllegalArgumentException("Nepoznat tip kolajdera");
                }
                
                Enemy enemy;
                if (enemyClass.equals("melee")) {
                    enemy = new MeleeEnemy(type, damage, health, x, y, collider);
                } else if (enemyClass.equals("boss")) {
                    enemy = new BossEnemy(type, damage, health, x, y, collider);
                } else {
                    throw new IllegalArgumentException("Nepoznata klasa neprijatelja");
                }
                
                loadedEnemies.add(enemy);
            } catch (Exception e) {
                throw new IllegalArgumentException("Greška pri parsiranju: " + e.getMessage());
            }
        }
        
        br.close();
        return loadedEnemies;
    }
}