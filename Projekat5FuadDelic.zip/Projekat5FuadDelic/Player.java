package projekat5;

public class Player extends GameObject {

    private String name;
    private int health;

    public Player(String name, int health, int x, int y, Collidable collider) {
        super(x, y, collider);
        setName(name);
        setHealth(health);
    }

    public String getName() {
    	return name;
    	}

    public void setName(String name) {
        if (name == null) name = "";
        name = name.trim();

        if (name.isEmpty())
            throw new IllegalArgumentException("Morate unijeti ime");

        name = name.substring(0,1).toUpperCase() + name.substring(1);

        this.name = name;
    }

    public int getHealth() {
    	return health;
    	}

    public void setHealth(int health) {
        if (health < 0 || health > 100)
            throw new IllegalArgumentException("Health mora biti izmedju 0 i 100");
        this.health = health;
    }

    @Override
    public String getDisplayName() {
        return name;
    }

    @Override
    public String toString() {
        return "Player[name=" + name + ", health=" + health +
                ", pos=(" + getX() + "," + getY() + "), collider=" + getCollider() + "]";
    }
}

