package udg.edu.me;

public class Konobar extends Zaposleni {
    private double prekovremeniSati;

    public Konobar(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati, double prekovremeniSati) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
        this.prekovremeniSati = prekovremeniSati;
    }

    public double getPrekovremeniSati() {
        return prekovremeniSati;
    }

    @Override
    public double izracunajPlatu() {
        double osnovna = ukupanBrojSati * plataPoSatu;
        double prekovremena = prekovremeniSati * (plataPoSatu * 1.2);
        return 4 * (osnovna + prekovremena);
    }

    @Override
    public String getTip() {
        return "Konobar";
    }
}

