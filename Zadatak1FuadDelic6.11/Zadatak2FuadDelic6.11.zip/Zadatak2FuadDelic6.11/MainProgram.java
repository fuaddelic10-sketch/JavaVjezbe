package udg.edu.me;

import java.util.List;

public class MainProgram {
    public static void main(String[] args) {
        Restoran restoran = new Restoran("Bistro 21", "Njegoševa 45, Podgorica", "123456789");

        // Dodavanje zaposlenih (različiti tipovi)
        restoran.dodajZaposlenog(new Konobar(1, "Marko", "Perić", 7.5, 40, 5));
        restoran.dodajZaposlenog(new Kuvar(2, "Jelena", "Kovačević", 10.0, 38));
        restoran.dodajZaposlenog(new Menadzer(3, "Miloš", "Popović", 12.0, 40, 300));
        restoran.dodajZaposlenog(new Konobar(4, "Ana", "Vuković", 7.0, 35, 0));
        restoran.dodajZaposlenog(new Kuvar(5, "Petar", "Božović", 9.0, 37));

        // Generisanje obračuna za mjesec
        List<ObracunPlate> obracuni = restoran.generisiObracun("Oktobar", 2025);

        // Ispis ukupnog troška
        double ukupniTrosak = restoran.ukupniTrosak(obracuni);
        System.out.printf("\nUkupan trošak plata za Oktobar 2025: %.2f EUR\n", ukupniTrosak);
    }
}
