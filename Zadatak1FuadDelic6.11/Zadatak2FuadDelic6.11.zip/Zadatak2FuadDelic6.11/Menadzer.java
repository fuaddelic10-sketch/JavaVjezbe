package udg.edu.me;

public class Menadzer extends Zaposleni {
    private final double osnovica = 1300.0;
    private double bonus;

    public Menadzer(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati, double bonus) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
        this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    @Override
    public double izracunajPlatu() {
        return osnovica + 4 * ukupanBrojSati * plataPoSatu + bonus;
    }

    @Override
    public String getTip() {
        return "Menadžer";
    }
}

