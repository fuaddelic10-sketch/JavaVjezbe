package udg.edu.me;

public class ObracunPlate {
    private String mjesec;
    private int godina;
    private Zaposleni zaposleni;
    private double iznos;
    private String napomena;

    public ObracunPlate(String mjesec, int godina, Zaposleni zaposleni, double iznos, String napomena) {
        this.setMjesec(mjesec);
        this.setGodina(godina);
        this.zaposleni = zaposleni;
        this.iznos = iznos;
        this.napomena = napomena;
    }

    public double getIznos() {
        return iznos;
    }

    @Override
    public String toString() {
        return String.format("%-5d %-10s %-10s %-12s %-10.2f € %-25s",
                zaposleni.getId(), zaposleni.getIme(), zaposleni.getPrezime(),
                zaposleni.getTip(), iznos, napomena);
    }

	public String getMjesec() {
		return mjesec;
	}

	public void setMjesec(String mjesec) {
		this.mjesec = mjesec;
	}

	public int getGodina() {
		return godina;
	}

	public void setGodina(int godina) {
		this.godina = godina;
	}
}
