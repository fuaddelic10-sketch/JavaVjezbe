package udg.edu.me;

import java.util.ArrayList;
import java.util.List;

public class Restoran {
    private String naziv;
    private String adresa;
    private String pib;
    private List<Zaposleni> zaposleniList = new ArrayList<>();

    public Restoran(String naziv, String adresa, String pib) {
        this.setNaziv(naziv);
        this.setAdresa(adresa);
        this.setPib(pib);
    }

    public void dodajZaposlenog(Zaposleni z) {
        zaposleniList.add(z);
    }

    public void ukloniZaposlenog(int id) {
        zaposleniList.removeIf(z -> z.getId() == id);
    }

    public Zaposleni pretraziPoId(int id) {
        for (Zaposleni z : zaposleniList) {
            if (z.getId() == id) return z;
        }
        return null;
    }

    public List<ObracunPlate> generisiObracun(String mjesec, int godina) {
        List<ObracunPlate> obracuni = new ArrayList<>();

        System.out.println("\n---------------------------------------------------------------");
        System.out.printf("%-5s %-10s %-10s %-12s %-10s %-25s\n", 
                          "ID", "Ime", "Prezime", "Tip", "Plata (€)", "Napomena");
        System.out.println("---------------------------------------------------------------");

        for (Zaposleni z : zaposleniList) {
            double plata = z.izracunajPlatu();
            String napomena = "";

            if (z instanceof Konobar) {
                Konobar k = (Konobar) z;
                if (k.getPrekovremeniSati() > 0)
                    napomena = "Uračunat prekovremeni rad";
            } else if (z instanceof Kuvar) {
                napomena = "Dodatak 1500 EUR";
            } else if (z instanceof Menadzer) {
                Menadzer m = (Menadzer) z;
                napomena = "Bonus: " + m.getBonus() + " EUR";
            }

            ObracunPlate op = new ObracunPlate(mjesec, godina, z, plata, napomena);
            obracuni.add(op);
            System.out.println(op);
        }

        System.out.println("---------------------------------------------------------------");
        return obracuni;
    }

    public double ukupniTrosak(List<ObracunPlate> obracuni) {
        double suma = 0;
        for (ObracunPlate op : obracuni) {
            suma += op.getIznos();
        }
        return suma;
    }

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getPib() {
		return pib;
	}

	public void setPib(String pib) {
		this.pib = pib;
	}

	public String getAdresa() {
		return adresa;
	}

	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}
}
